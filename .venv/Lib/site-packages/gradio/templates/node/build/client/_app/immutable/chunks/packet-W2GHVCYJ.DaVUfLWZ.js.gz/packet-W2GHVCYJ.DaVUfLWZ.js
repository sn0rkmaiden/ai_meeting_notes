import { P, a } from "./mermaid-parser.core.B39mVJqj.js";
export {
  P as PacketModule,
  a as createPacketServices
};
