import { V, _ } from "../chunks/2.Cy8pFCNp.js";
export {
  V as component,
  _ as universal
};
