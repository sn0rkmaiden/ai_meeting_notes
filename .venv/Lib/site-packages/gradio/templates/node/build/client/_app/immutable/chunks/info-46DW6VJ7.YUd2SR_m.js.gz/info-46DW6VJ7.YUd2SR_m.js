import { I, c } from "./mermaid-parser.core.B39mVJqj.js";
export {
  I as InfoModule,
  c as createInfoServices
};
