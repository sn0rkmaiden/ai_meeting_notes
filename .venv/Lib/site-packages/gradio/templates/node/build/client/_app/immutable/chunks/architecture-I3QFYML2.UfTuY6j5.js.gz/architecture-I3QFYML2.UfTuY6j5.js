import { A, e } from "./mermaid-parser.core.B39mVJqj.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
